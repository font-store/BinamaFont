<?php
return [
    "paypingCode" => "5Ft0",
    "AllDonates"  => "lastDonate.json",
    "masterDonate" => 'binama.json'
];

