<?php
    $config = require('config.php');
    $masterDonate = json_decode(file_get_contents($config['masterDonate']), true);

    $AllDonates = json_decode(file_get_contents($config['AllDonates']));
    

    
$out = [];
foreach($AllDonates as $key => $val){
    $res = [];

    if (!array_key_exists($val->Code, $masterDonate)) {
        $res = [
        'FullName' => $val->FullName,
        'CustomDescription' => $val->CustomDescription,
        'EmailMD5' => md5(strtolower($val->Email)),
        'PayDateDisplay' => $val->PayDateDisplay,
    ];

        if ($res['CustomDescription'] == 'وارد نشده') {
            $res['CustomDescription'] = '#';
        }
        $out[$val->Code] = $res;
    }
}

$newFile = basename($config['masterDonate'], '.json').'-new.json';
print_r($newFile);
file_put_contents($newFile,json_encode($out,JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ));